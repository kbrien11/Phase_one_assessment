def print_items(a_list):
    for i in a_list:
        if type(i) == type([]):
            print_items(i)
        else:
            print(i)


sample = [1, 2, ['jeff', 'tom'], [42, ['billy', 'jason']]]

print_items(sample)
